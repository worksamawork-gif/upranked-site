import { useState, useEffect } from 'react';
import { Menu, X, Globe } from 'lucide-react';
import { Link } from 'wouter';

export default function Navigation() {
  const [isOpen, setIsOpen] = useState(false);
  const [language, setLanguage] = useState<'en' | 'ar'>('en');
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const toggleLanguage = () => {
    const newLang = language === 'en' ? 'ar' : 'en';
    setLanguage(newLang);
    document.documentElement.lang = newLang;
    document.documentElement.dir = newLang === 'ar' ? 'rtl' : 'ltr';
  };

  const navItems = language === 'en' ? [
    { label: 'Services', href: '#services' },
    { label: 'About', href: '/about' },
    { label: 'Blog', href: '/blog' },
    { label: 'Contact', href: '/contact' },
  ] : [
    { label: 'الخدمات', href: '#services' },
    { label: 'من نحن', href: '/about' },
    { label: 'المدونة', href: '/blog' },
    { label: 'اتصل بنا', href: '/contact' },
  ];

  const ctaLabel = language === 'en' ? 'Book a Call' : 'احجز استشارة';

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled ? 'bg-navy/95 backdrop-blur-md border-b border-border' : 'bg-transparent'
      }`}
    >
      <div className="container-premium flex items-center justify-between h-20">
        {/* Logo */}
        <Link href="/">
          <a className="flex items-center gap-2 group">
            <div className="w-10 h-10 bg-gradient-to-br from-accent to-yellow-500 rounded-lg flex items-center justify-center">
              <span className="text-black font-bold text-lg">U</span>
            </div>
            <span className="hidden md:inline font-bold text-lg group-hover:text-accent transition-colors">
              upranked.io
            </span>
          </a>
        </Link>

        {/* Desktop Navigation */}
        <div className="hidden md:flex items-center gap-8">
          {navItems.map((item) => (
            <Link key={item.label} href={item.href}>
              <a className="text-text-secondary hover:text-accent transition-colors duration-300 font-medium">
                {item.label}
              </a>
            </Link>
          ))}
        </div>

        {/* Right Actions */}
        <div className="flex items-center gap-4">
          {/* Language Toggle */}
          <button
            onClick={toggleLanguage}
            className="p-2 hover:bg-dark-gray rounded-lg transition-colors duration-300 flex items-center gap-2"
            aria-label="Toggle language"
          >
            <Globe className="w-5 h-5 text-accent" />
            <span className="hidden md:inline text-sm font-semibold text-accent">
              {language.toUpperCase()}
            </span>
          </button>

          {/* CTA Button */}
          <button className="hidden md:inline-block px-6 py-2 bg-accent text-black rounded-lg font-semibold hover:bg-yellow-500 transition-all duration-300 shadow-lg hover:shadow-xl hover:shadow-accent/30">
            {ctaLabel}
          </button>

          {/* Mobile Menu Toggle */}
          <button
            onClick={() => setIsOpen(!isOpen)}
            className="md:hidden p-2 hover:bg-dark-gray rounded-lg transition-colors"
            aria-label="Toggle menu"
          >
            {isOpen ? (
              <X className="w-6 h-6 text-accent" />
            ) : (
              <Menu className="w-6 h-6 text-accent" />
            )}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {isOpen && (
        <div className="md:hidden bg-dark-gray border-t border-border animate-fade-in-down">
          <div className="container-premium py-4 space-y-4">
            {navItems.map((item) => (
              <Link key={item.label} href={item.href}>
                <a
                  className="block py-2 text-text-secondary hover:text-accent transition-colors font-medium"
                  onClick={() => setIsOpen(false)}
                >
                  {item.label}
                </a>
              </Link>
            ))}
            <button className="w-full mt-4 px-6 py-3 bg-accent text-black rounded-lg font-semibold hover:bg-yellow-500 transition-all duration-300">
              {ctaLabel}
            </button>
          </div>
        </div>
      )}
    </nav>
  );
}
