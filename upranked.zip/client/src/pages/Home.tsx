import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { ChevronDown, Zap, TrendingUp, Code, Briefcase, Globe } from 'lucide-react';
import { Link } from 'wouter';

export default function Home() {
  const [language, setLanguage] = useState<'en' | 'ar'>('en');

  useEffect(() => {
    const lang = document.documentElement.lang || 'en';
    setLanguage(lang as 'en' | 'ar');
  }, []);

  const content = language === 'en' ? {
    headline: 'upranked.io – Premium Growth Intelligence Lab',
    subheadline: 'Strategic SEO and Growth Intelligence for High-Value Clients in the GCC',
    cta: 'Book Your Free Strategy Call with Sam Hamouda',
    services: 'Our Services',
    servicesDesc: 'Comprehensive solutions designed for premium growth',
    medicalSEO: 'Medical SEO',
    medicalDesc: 'Specialized SEO for healthcare providers and medical practices',
    industrialSEO: 'Industrial SEO',
    industrialDesc: 'B2B digital transformation for manufacturing and industrial sectors',
    growthIntelligence: 'Growth Intelligence',
    growthDesc: '1-on-1 strategic consultation with founder Sam Hamouda',
    tailoredTools: 'Tailored Tools',
    toolsDesc: 'Custom software solutions for your unique business needs',
    tailoredWebsite: 'Tailored Website',
    websiteDesc: 'Premium web design and development for maximum conversion',
    scrollDown: 'Scroll to explore',
  } : {
    headline: 'upranked.io – مختبر النمو الذكي المتميز',
    subheadline: 'استراتيجية تحسين محركات البحث وذكاء النمو للعملاء ذوي القيمة العالية في منطقة الخليج',
    cta: 'احجز استشارتك الاستراتيجية المجانية مع سام حمودة',
    services: 'خدماتنا',
    servicesDesc: 'حلول شاملة مصممة لنمو متميز',
    medicalSEO: 'تحسين محركات البحث الطبية',
    medicalDesc: 'تحسين متخصص لمقدمي الخدمات الصحية والعيادات الطبية',
    industrialSEO: 'تحسين محركات البحث الصناعية',
    industrialDesc: 'التحول الرقمي B2B للقطاع الصناعي والتصنيعي',
    growthIntelligence: 'ذكاء النمو',
    growthDesc: 'استشارة استراتيجية 1-على-1 مع المؤسس سام حمودة',
    tailoredTools: 'أدوات مخصصة',
    toolsDesc: 'حلول برمجية مخصصة لاحتياجات عملك الفريدة',
    tailoredWebsite: 'موقع مخصص',
    websiteDesc: 'تصميم وتطوير ويب متميز لأقصى تحويل',
    scrollDown: 'اسحب للاستكشاف',
  };

  const services = [
    {
      title: content.medicalSEO,
      description: content.medicalDesc,
      icon: Zap,
      href: '/services/medical-seo',
    },
    {
      title: content.industrialSEO,
      description: content.industrialDesc,
      icon: TrendingUp,
      href: '/services/industrial-seo',
    },
    {
      title: content.growthIntelligence,
      description: content.growthDesc,
      icon: Briefcase,
      href: '/services/growth-intelligence',
    },
    {
      title: content.tailoredTools,
      description: content.toolsDesc,
      icon: Code,
      href: '/services/tailored-tools',
    },
    {
      title: content.tailoredWebsite,
      description: content.websiteDesc,
      icon: Globe,
      href: '/services/tailored-website',
    },
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
        delayChildren: 0.3,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.8 },
    },
  };

  return (
    <div className="min-h-screen bg-navy text-white">
      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center pt-20 pb-10 px-4 md:px-6 lg:px-8 texture-overlay">
        <div className="absolute inset-0 bg-gradient-to-br from-navy via-dark-gray to-navy opacity-50 -z-10"></div>

        <motion.div
          className="max-w-5xl mx-auto text-center"
          variants={containerVariants}
          initial="hidden"
          animate="visible"
        >
          {/* Animated Headline */}
          <motion.h1
            variants={itemVariants}
            className="text-5xl md:text-6xl lg:text-7xl font-bold mb-6 leading-tight"
          >
            <span className="block mb-4">{content.headline}</span>
          </motion.h1>

          {/* Subheadline */}
          <motion.p
            variants={itemVariants}
            className="text-xl md:text-2xl text-text-secondary mb-8 leading-relaxed max-w-3xl mx-auto"
          >
            {content.subheadline}
          </motion.p>

          {/* Trust Signals */}
          <motion.div
            variants={itemVariants}
            className="flex flex-wrap justify-center gap-4 md:gap-6 mb-12 text-sm md:text-base"
          >
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 bg-accent rounded-full"></div>
              <span className="text-text-secondary">Founded by Sam Hamouda</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 bg-accent rounded-full"></div>
              <span className="text-text-secondary">APEX Framework™ Methodology</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 bg-accent rounded-full"></div>
              <span className="text-text-secondary">GCC Market Experts</span>
            </div>
          </motion.div>

          {/* CTA Button */}
          <motion.div variants={itemVariants} className="mb-12">
            <button className="btn-primary text-lg md:text-xl px-10 md:px-12 py-5 md:py-6 hover:shadow-2xl hover:shadow-accent/40 transform hover:scale-105 transition-all duration-300">
              {content.cta}
            </button>
          </motion.div>

          {/* Scroll Indicator */}
          <motion.div
            variants={itemVariants}
            className="flex flex-col items-center gap-2 mt-16"
            animate={{ y: [0, 10, 0] }}
            transition={{ duration: 2, repeat: Infinity }}
          >
            <span className="text-text-secondary text-sm">{content.scrollDown}</span>
            <ChevronDown className="w-6 h-6 text-accent" />
          </motion.div>
        </motion.div>
      </section>

      {/* Services Section */}
      <section id="services" className="section-padding bg-dark-gray">
        <div className="container-premium">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="section-title text-accent mb-4">{content.services}</h2>
            <p className="section-subtitle">{content.servicesDesc}</p>
          </motion.div>

          {/* Service Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
            {services.map((service, index) => {
              const Icon = service.icon;
              return (
                <motion.div
                  key={service.title}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  viewport={{ once: true }}
                  whileHover={{ y: -8 }}
                  className="group"
                >
                  <Link href={service.href}>
                    <a className="card-premium-hover h-full flex flex-col gap-4 p-6 md:p-8 cursor-pointer">
                      <div className="w-12 h-12 bg-gradient-to-br from-accent to-yellow-500 rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
                        <Icon className="w-6 h-6 text-black" />
                      </div>
                      <h3 className="text-xl font-bold text-white">{service.title}</h3>
                      <p className="text-text-secondary flex-1">{service.description}</p>
                      <div className="text-accent font-semibold group-hover:translate-x-2 transition-transform duration-300">
                        Learn More →
                      </div>
                    </a>
                  </Link>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="section-padding bg-navy">
        <div className="container-premium text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <h2 className="text-4xl md:text-5xl font-bold mb-6">
              Ready to Transform Your Growth?
            </h2>
            <p className="text-xl text-text-secondary mb-8 max-w-2xl mx-auto">
              Schedule a free strategy call with Sam Hamouda to discover how the APEX Framework™ can accelerate your business.
            </p>
            <button className="btn-primary text-lg px-10 py-5 hover:shadow-2xl hover:shadow-accent/40 transform hover:scale-105 transition-all duration-300">
              {content.cta}
            </button>
          </motion.div>
        </div>
      </section>
    </div>
  );
}
