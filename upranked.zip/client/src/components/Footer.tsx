import { Mail, Phone, MapPin, Linkedin, Twitter } from 'lucide-react';
import { Link } from 'wouter';
import { useState, useEffect } from 'react';

export default function Footer() {
  const [language, setLanguage] = useState<'en' | 'ar'>('en');

  useEffect(() => {
    const lang = document.documentElement.lang || 'en';
    setLanguage(lang as 'en' | 'ar');
  }, []);

  const content = language === 'en' ? {
    tagline: 'Premium Growth Intelligence Lab',
    services: 'Services',
    medicalSEO: 'Medical SEO',
    industrialSEO: 'Industrial SEO',
    growthIntelligence: 'Growth Intelligence',
    tailoredTools: 'Tailored Tools',
    tailoredWebsite: 'Tailored Website',
    company: 'Company',
    about: 'About',
    blog: 'Blog',
    contact: 'Contact',
    legal: 'Legal',
    privacy: 'Privacy Policy',
    terms: 'Terms of Service',
    contact_info: 'Contact Info',
    email: 'hello@upranked.io',
    phone: '+971 50 123 4567',
    location: 'Dubai, UAE',
    rights: '© 2026 upranked.io. All rights reserved.',
  } : {
    tagline: 'مختبر النمو الذكي المتميز',
    services: 'الخدمات',
    medicalSEO: 'تحسين محركات البحث الطبية',
    industrialSEO: 'تحسين محركات البحث الصناعية',
    growthIntelligence: 'ذكاء النمو',
    tailoredTools: 'أدوات مخصصة',
    tailoredWebsite: 'موقع مخصص',
    company: 'الشركة',
    about: 'من نحن',
    blog: 'المدونة',
    contact: 'اتصل بنا',
    legal: 'القانوني',
    privacy: 'سياسة الخصوصية',
    terms: 'شروط الخدمة',
    contact_info: 'معلومات الاتصال',
    email: 'hello@upranked.io',
    phone: '+971 50 123 4567',
    location: 'دبي، الإمارات العربية المتحدة',
    rights: '© 2026 upranked.io. جميع الحقوق محفوظة.',
  };

  return (
    <footer className="bg-dark-gray border-t border-border mt-20">
      {/* Main Footer Content */}
      <div className="container-premium py-16 md:py-20">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
          {/* Brand Column */}
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 bg-gradient-to-br from-accent to-yellow-500 rounded-lg flex items-center justify-center">
                <span className="text-black font-bold text-lg">U</span>
              </div>
              <div>
                <p className="font-bold text-lg">upranked.io</p>
                <p className="text-sm text-text-secondary">{content.tagline}</p>
              </div>
            </div>
            <p className="text-text-secondary text-sm leading-relaxed">
              {language === 'en'
                ? 'Premium SEO and Growth Intelligence services for high-value clients in the GCC region.'
                : 'خدمات تحسين محركات البحث وذكاء النمو المتميزة للعملاء ذوي القيمة العالية في منطقة الخليج.'}
            </p>
          </div>

          {/* Services Column */}
          <div>
            <h4 className="font-bold text-lg mb-6 text-accent">{content.services}</h4>
            <ul className="space-y-3">
              <li>
                <Link href="/services/medical-seo">
                  <a className="text-text-secondary hover:text-accent transition-colors">{content.medicalSEO}</a>
                </Link>
              </li>
              <li>
                <Link href="/services/industrial-seo">
                  <a className="text-text-secondary hover:text-accent transition-colors">{content.industrialSEO}</a>
                </Link>
              </li>
              <li>
                <Link href="/services/growth-intelligence">
                  <a className="text-text-secondary hover:text-accent transition-colors">{content.growthIntelligence}</a>
                </Link>
              </li>
              <li>
                <Link href="/services/tailored-tools">
                  <a className="text-text-secondary hover:text-accent transition-colors">{content.tailoredTools}</a>
                </Link>
              </li>
              <li>
                <Link href="/services/tailored-website">
                  <a className="text-text-secondary hover:text-accent transition-colors">{content.tailoredWebsite}</a>
                </Link>
              </li>
            </ul>
          </div>

          {/* Company Column */}
          <div>
            <h4 className="font-bold text-lg mb-6 text-accent">{content.company}</h4>
            <ul className="space-y-3">
              <li>
                <Link href="/about">
                  <a className="text-text-secondary hover:text-accent transition-colors">{content.about}</a>
                </Link>
              </li>
              <li>
                <Link href="/blog">
                  <a className="text-text-secondary hover:text-accent transition-colors">{content.blog}</a>
                </Link>
              </li>
              <li>
                <Link href="/contact">
                  <a className="text-text-secondary hover:text-accent transition-colors">{content.contact}</a>
                </Link>
              </li>
            </ul>
          </div>

          {/* Contact Column */}
          <div>
            <h4 className="font-bold text-lg mb-6 text-accent">{content.contact_info}</h4>
            <ul className="space-y-4">
              <li className="flex items-start gap-3">
                <Mail className="w-5 h-5 text-accent flex-shrink-0 mt-1" />
                <a href={`mailto:${content.email}`} className="text-text-secondary hover:text-accent transition-colors">
                  {content.email}
                </a>
              </li>
              <li className="flex items-start gap-3">
                <Phone className="w-5 h-5 text-accent flex-shrink-0 mt-1" />
                <a href={`tel:${content.phone}`} className="text-text-secondary hover:text-accent transition-colors">
                  {content.phone}
                </a>
              </li>
              <li className="flex items-start gap-3">
                <MapPin className="w-5 h-5 text-accent flex-shrink-0 mt-1" />
                <span className="text-text-secondary">{content.location}</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Divider */}
        <div className="border-t border-border my-8"></div>

        {/* Bottom Footer */}
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          <p className="text-text-secondary text-sm">{content.rights}</p>

          {/* Social Links */}
          <div className="flex items-center gap-4">
            <a
              href="https://linkedin.com"
              target="_blank"
              rel="noopener noreferrer"
              className="p-2 hover:bg-navy rounded-lg transition-colors"
              aria-label="LinkedIn"
            >
              <Linkedin className="w-5 h-5 text-accent" />
            </a>
            <a
              href="https://twitter.com"
              target="_blank"
              rel="noopener noreferrer"
              className="p-2 hover:bg-navy rounded-lg transition-colors"
              aria-label="Twitter"
            >
              <Twitter className="w-5 h-5 text-accent" />
            </a>
          </div>

          {/* Legal Links */}
          <div className="flex items-center gap-6">
            <Link href="/privacy">
              <a className="text-text-secondary hover:text-accent transition-colors text-sm">{content.privacy}</a>
            </Link>
            <Link href="/terms">
              <a className="text-text-secondary hover:text-accent transition-colors text-sm">{content.terms}</a>
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
